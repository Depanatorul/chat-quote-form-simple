(function(){'use strict';
function q(sel,root){return (root||document).querySelector(sel);}
function qa(sel,root){return Array.prototype.slice.call((root||document).querySelectorAll(sel));}
function enc(s){return encodeURIComponent(s||'');}
function getVal(root,id){var el=q('#'+id,root);return el?String(el.value||'').trim():'';}
function captchaToken(){
  try{ if(window.grecaptcha && typeof window.grecaptcha.getResponse==='function'){ return window.grecaptcha.getResponse()||''; } }catch(e){}
  return '';
}
function getPhone(root){
  var p='';
  try{ if(root && root.getAttribute){ p = root.getAttribute('data-wqfs-phone')||''; } }catch(e){}
  if(!p && window.WQFS && WQFS.phone){ p = String(WQFS.phone); }
  p = (p||'').replace(/[^0-9]/g,'');
  return p;
}
function buildMessage(root){
  var fallback="Hello, I would like a quote.\n\nName: {{name}}\nLocation: {{location}}\nVehicle: {{make}} {{model}} ({{year}})\nProblem: {{problem}}\nBest time to contact: {{time}}\n\nSent from: {{service_url}}";
  var t=(window.WQFS && WQFS.template)?String(WQFS.template):fallback;
  var map={
    '{{name}}':getVal(root,'wqfs_name'),
    '{{location}}':getVal(root,'wqfs_location'),
    '{{make}}':getVal(root,'wqfs_make'),
    '{{model}}':getVal(root,'wqfs_model'),
    '{{year}}':getVal(root,'wqfs_year'),
    '{{problem}}':getVal(root,'wqfs_problem'),
    '{{time}}':getVal(root,'wqfs_time'),
    '{{service_url}}':(window.WQFS && WQFS.serviceUrl)?String(WQFS.serviceUrl):''
  };
  Object.keys(map).forEach(function(k){ t=t.split(k).join(map[k]); });
  return t;
}
function buildChatUrl(root, message){
  var phone=getPhone(root);
  if(!phone){ return ''; }
  // This link opens WhatsApp if installed, otherwise web flow.
  return 'https://api.whatsapp.com/send?phone='+phone+'&text='+enc(message);
}
function showError(root,msg){
  var old=q('.wqfs-inline-error',root);
  if(old){old.remove();}
  if(!msg){return;}
  var div=document.createElement('div');
  div.className='wqfs-inline-error wqfs-error';
  div.textContent=msg;
  var form=q('form.wqfs-form',root);
  if(form){form.insertBefore(div,form.firstChild);}
}
function validateRequired(root){
  var ids=['wqfs_name','wqfs_location','wqfs_make','wqfs_model','wqfs_year','wqfs_problem'];
  for(var i=0;i<ids.length;i++){ if(!getVal(root,ids[i])){return false;} }
  return true;
}
function setBtn(root,enabled){
  var btn=q('[data-wqfs-btn="1"]',root); if(!btn){return;}
  btn.disabled=!enabled;
}
function verifyCaptchaAndNavigate(root, targetWin, message){
  var token=captchaToken();
  var ajaxUrl=(window.WQFS && WQFS.ajaxUrl)?String(WQFS.ajaxUrl):'';
  var nonce=(window.WQFS && WQFS.nonce)?String(WQFS.nonce):'';

  var fd=new FormData();
  fd.append('action','wqfs_verify_captcha');
  fd.append('nonce',nonce);
  fd.append('token',token);

  fetch(ajaxUrl,{method:'POST',credentials:'same-origin',body:fd})
    .then(function(r){return r.json();})
    .then(function(j){
      if(j && j.success){
        var url=buildChatUrl(root,message);
        if(!url){ showError(root,'Destination phone number is not set.'); try{targetWin.close();}catch(e){} return; }
        targetWin.location.href=url;
        showError(root,'');
      }else{
        showError(root,'Captcha failed. Please try again.');
        try{targetWin.close();}catch(e){}
      }
    })
    .catch(function(){
      showError(root,'Captcha verification error.');
      try{targetWin.close();}catch(e){}
    });
}
function bind(root){
  var btn=q('[data-wqfs-btn="1"]',root); if(!btn){return;}

  function refresh(){
    var ok=validateRequired(root);
    if(window.WQFS && WQFS.requireCaptcha==1){
      ok = ok && (captchaToken().length>0);
    }
    setBtn(root,ok);
  }

  qa('input,textarea,select',root).forEach(function(el){
    el.addEventListener('input',refresh);
    el.addEventListener('change',refresh);
  });

  btn.addEventListener('click',function(){
    if(!validateRequired(root)){
      showError(root,'Please fill in all required fields.');
      refresh();
      return;
    }
    var msg=buildMessage(root);
    if(window.WQFS && WQFS.requireCaptcha==1){
      var w=window.open('about:blank','_blank','noopener');
      if(!w){ showError(root,'Popup blocked. Please allow popups and try again.'); return; }
      verifyCaptchaAndNavigate(root,w,msg);
    }else{
      var url=buildChatUrl(root,msg);
      if(!url){ showError(root,'Destination phone number is not set.'); return; }
      window.open(url,'_blank','noopener');
    }
  });

  refresh();
}
document.addEventListener('DOMContentLoaded',function(){
  qa('[data-wqfs="1"]').forEach(bind);
});
window.wqfsCaptchaOk=function(){ try{ qa('[data-wqfs="1"]').forEach(function(root){ var ev=document.createEvent('Event'); ev.initEvent('input',true,true); root.dispatchEvent(ev); }); }catch(e){} };
window.wqfsCaptchaExpired=function(){ try{ qa('[data-wqfs="1"]').forEach(function(root){ var btn=q('[data-wqfs-btn="1"]',root); if(btn){btn.disabled=true;} }); }catch(e){} };
})();
