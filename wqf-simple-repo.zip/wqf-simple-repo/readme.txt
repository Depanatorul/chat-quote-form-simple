=== Chat Quote Form Simple ===
Contributors: gsmhelp
Tags: quote, contact form, chat, recaptcha
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.1.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Short, lightweight quote request form that opens a chat app with a pre-filled message.

== Description ==
This plugin provides a simple quote request form via shortcode. Visitors enter their details and the plugin opens a chat app with a pre-filled message they can review before sending.

Optional Google reCAPTCHA v2 can be enabled to reduce spam.

Shortcode:
- [chat_quote_form]

== Installation ==
1. Upload the plugin ZIP via Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Go to Settings > Chat Quote Form Simple and set your destination phone number.
4. Add shortcode [chat_quote_form] to any page.

== Changelog ==
= 1.1.2 =
* Initial release.
