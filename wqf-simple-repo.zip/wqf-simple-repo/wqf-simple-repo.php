<?php
/**
 * Plugin Name: Chat Quote Form Simple
 * Description: Simple chat-app quote request form via shortcode, with optional Google reCAPTCHA v2.
 * Version: 1.1.2
 * Author: GsmHelp Electronics Workshop
 * Author URI: https://www.service-evesham.uk
 * License: GPLv2 or later
 * Text Domain: wqf-simple-repo
 */

if (!defined('ABSPATH')) { exit; }

define('WQFS_VERSION', '1.1.2');
define('WQFS_DIR', plugin_dir_path(__FILE__));
define('WQFS_URL', plugin_dir_url(__FILE__));

require_once WQFS_DIR . 'includes/admin-settings.php';

final class WQFS_Plugin
{
    public static function init(): void
    {
        add_action('init', array(__CLASS__, 'register_shortcodes'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'register_assets'));
        add_action('wp_ajax_wqfs_verify_captcha', array(__CLASS__, 'verify_captcha'));
        add_action('wp_ajax_nopriv_wqfs_verify_captcha', array(__CLASS__, 'verify_captcha'));
    }

    public static function register_assets(): void
    {
        wp_register_style('wqfs-style', WQFS_URL . 'assets/css/wqfs.css', array(), WQFS_VERSION);
        wp_register_script('wqfs-script', WQFS_URL . 'assets/js/wqfs.js', array(), WQFS_VERSION, true);
    }

    public static function register_shortcodes(): void
    {
        // Primary shortcode
        add_shortcode('chat_quote_form', array(__CLASS__, 'render'));

        // Backwards compatible alias (optional)
        add_shortcode('gsmhelp_quote', array(__CLASS__, 'render'));
    }

    private static function opt(string $key, string $default = ''): string
    {
        $opts = get_option('wqfs_settings', array());
        if (is_array($opts) && isset($opts[$key]) && $opts[$key] !== '') {
            return (string)$opts[$key];
        }
        return $default;
    }

    private static function normalize_phone(string $raw): string
    {
        $digits = preg_replace('/[^0-9]/', '', $raw);
        return is_string($digits) ? $digits : '';
    }

    private static function is_enabled($val): bool
    {
        if (is_bool($val)) { return $val; }
        if (is_numeric($val)) { return ((int)$val) === 1; }
        $val = strtolower((string)$val);
        return in_array($val, array('1','true','yes','on'), true);
    }

    public static function render($atts = array()): string
    {
        $atts = shortcode_atts(array(
            'title' => 'Get a Quick Quote',
            'intro' => 'Fill in your details below. A chat app will open with a pre-filled message you can review before sending.',
            'button' => 'Open Chat App',
        ), $atts, 'chat_quote_form');

        $serviceUrlFixed = 'https://www.service-evesham.uk';

        $phone = self::normalize_phone(self::opt('phone', ''));
        if ($phone === '') {
            return '<div class="wqfs-error">Please set your destination phone number in Settings &gt; Chat Quote Form Simple.</div>';
        }

        $captchaEnabled = self::is_enabled(self::opt('captcha_enabled', '0'));
        $siteKey = trim(self::opt('captcha_site_key', ''));
        $secretKey = trim(self::opt('captcha_secret_key', ''));
        $useCaptcha = $captchaEnabled && ($siteKey !== '') && ($secretKey !== '');

        wp_enqueue_style('wqfs-style');
        wp_enqueue_script('wqfs-script');

        $nonce = wp_create_nonce('wqfs_nonce');

        $template = "Hello, I would like a quote.\n\n"
            . "Name: {name}\n"
            . "Location: {location}\n"
            . "Vehicle: {make} {model} ({year})\n"
            . "Problem: {problem}\n"
            . "Best time to contact: {time}\n\n"
            . "Sent from: {service_url}";

        wp_localize_script('wqfs-script', 'WQFS', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => $nonce,
            'phone' => $phone,
            'template' => $template,
            'serviceUrl' => esc_url_raw($serviceUrlFixed),
            'requireCaptcha' => $useCaptcha ? 1 : 0,
        ));

        if ($useCaptcha) {
            $lang = substr(get_locale(), 0, 2);
            $lang = preg_replace('/[^a-z]/i', '', $lang);
            if ($lang === '') { $lang = 'en'; }

            // Provide a version to satisfy Plugin Check warning.
            wp_enqueue_script(
                'google-recaptcha',
                'https://www.google.com/recaptcha/api.js?hl=' . rawurlencode($lang),
                array(),
                WQFS_VERSION,
                true
            );
        }

        $html  = '<div class="wqfs-wrap" data-wqfs="1" data-wqfs-phone="' . esc_attr($phone) . '">';
        $html .= '<div class="wqfs-card">';
        $html .= '<h2 class="wqfs-title">' . esc_html((string)$atts['title']) . '</h2>';
        $html .= '<p class="wqfs-intro">' . esc_html((string)$atts['intro']) . '</p>';

        if ($captchaEnabled && !$useCaptcha) {
            $html .= '<div class="wqfs-warn">Captcha enabled but keys are missing. Set Site Key and Secret Key in Settings.</div>';
        }

        $html .= '<form class="wqfs-form" autocomplete="on" novalidate>';
        $html .= self::field_text('wqfs_name', 'Name', 'Your full name', true);
        $html .= self::field_text('wqfs_location', 'Location', 'Postcode or town', true);

        $html .= '<div class="wqfs-grid">';
        $html .= self::field_text('wqfs_make', 'Vehicle Make', 'e.g. Ford, BMW', true, true);
        $html .= self::field_text('wqfs_model', 'Model', 'e.g. Focus, 3 Series', true, true);
        $html .= '</div>';

        $html .= self::field_number('wqfs_year', 'Year of Manufacture', 'e.g. 2020', true);
        $html .= self::field_textarea('wqfs_problem', 'Problem Description', 'Describe the issue or service needed', true);

        $html .= self::field_select('wqfs_time', 'Best Time to Contact', array(
            '' => 'Select preferred time',
            'ASAP' => 'ASAP',
            'Morning (08:00–12:00)' => 'Morning (08:00–12:00)',
            'Afternoon (12:00–17:00)' => 'Afternoon (12:00–17:00)',
            'Evening (17:00–20:00)' => 'Evening (17:00–20:00)',
            'Anytime' => 'Anytime'
        ));

        if ($useCaptcha) {
            $html .= '<div class="wqfs-field wqfs-captcha">';
            $html .= '<div class="g-recaptcha" data-sitekey="' . esc_attr($siteKey) . '" data-callback="wqfsCaptchaOk" data-expired-callback="wqfsCaptchaExpired"></div>';
            $html .= '<div class="wqfs-help">Complete captcha to enable the button.</div>';
            $html .= '</div>';
        }

        $html .= '<button type="button" class="wqfs-btn" data-wqfs-btn="1" disabled="disabled">' . esc_html((string)$atts['button']) . '</button>';
        $html .= '</form>';

        // IMPORTANT for WordPress.org: avoid forced SEO backlinks.
        // Keep this as a simple credit link and set to nofollow for repository compliance.
        $html .= '<div class="wqfs-foot">Plugin by <a href="' . esc_url($serviceUrlFixed) . '" target="_blank" rel="nofollow noopener">GsmHelp</a></div>';

        $html .= '</div></div>';

        return $html;
    }

    private static function field_text(string $id, string $label, string $placeholder, bool $required, bool $grid = false): string
    {
        $req = $required ? ' <span class="wqfs-req">*</span>' : '';
        $r = $required ? 'required' : '';
        $wrap = $grid ? 'wqfs-field wqfs-field-grid' : 'wqfs-field';

        return '<div class="' . esc_attr($wrap) . '">'
            . '<label for="' . esc_attr($id) . '">' . esc_html($label) . $req . '</label>'
            . '<input id="' . esc_attr($id) . '" name="' . esc_attr($id) . '" type="text" placeholder="' . esc_attr($placeholder) . '" ' . $r . ' />'
            . '</div>';
    }

    private static function field_number(string $id, string $label, string $placeholder, bool $required): string
    {
        $req = $required ? ' <span class="wqfs-req">*</span>' : '';
        $r = $required ? 'required' : '';
        $yearMin = 1980;
        $yearMax = (int)gmdate('Y') + 1;

        return '<div class="wqfs-field">'
            . '<label for="' . esc_attr($id) . '">' . esc_html($label) . $req . '</label>'
            . '<input id="' . esc_attr($id) . '" name="' . esc_attr($id) . '" type="number" inputmode="numeric" min="' . esc_attr((string)$yearMin) . '" max="' . esc_attr((string)$yearMax) . '" placeholder="' . esc_attr($placeholder) . '" ' . $r . ' />'
            . '</div>';
    }

    private static function field_textarea(string $id, string $label, string $placeholder, bool $required): string
    {
        $req = $required ? ' <span class="wqfs-req">*</span>' : '';
        $r = $required ? 'required' : '';

        return '<div class="wqfs-field">'
            . '<label for="' . esc_attr($id) . '">' . esc_html($label) . $req . '</label>'
            . '<textarea id="' . esc_attr($id) . '" name="' . esc_attr($id) . '" placeholder="' . esc_attr($placeholder) . '" rows="4" ' . $r . '></textarea>'
            . '</div>';
    }

    private static function field_select(string $id, string $label, array $options): string
    {
        $html  = '<div class="wqfs-field">';
        $html .= '<label for="' . esc_attr($id) . '">' . esc_html($label) . '</label>';
        $html .= '<select id="' . esc_attr($id) . '" name="' . esc_attr($id) . '">';

        foreach ($options as $value => $text) {
            $html .= '<option value="' . esc_attr((string)$value) . '">' . esc_html((string)$text) . '</option>';
        }

        $html .= '</select></div>';
        return $html;
    }

    public static function verify_captcha(): void
    {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string)$_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'wqfs_nonce')) {
            wp_send_json_error(array('message' => 'Invalid nonce.'), 403);
        }

        $captchaEnabled = self::is_enabled(self::opt('captcha_enabled', '0'));
        $siteKey = trim(self::opt('captcha_site_key', ''));
        $secret = trim(self::opt('captcha_secret_key', ''));

        if (!$captchaEnabled || $siteKey === '' || $secret === '') {
            wp_send_json_success(array('ok' => true));
        }

        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash((string)$_POST['token'])) : '';
        if ($token === '') {
            wp_send_json_error(array('message' => 'Missing captcha token.'), 400);
        }

        $remoteIp = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash((string)$_SERVER['REMOTE_ADDR'])) : '';

        $resp = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', array(
            'timeout' => 10,
            'body' => array(
                'secret' => $secret,
                'response' => $token,
                'remoteip' => $remoteIp,
            ),
        ));

        if (is_wp_error($resp)) {
            wp_send_json_error(array('message' => 'Captcha verification error.'), 500);
        }

        $body = wp_remote_retrieve_body($resp);
        $data = json_decode($body, true);

        if (!is_array($data) || !isset($data['success']) || $data['success'] !== true) {
            wp_send_json_error(array('message' => 'Captcha failed.'), 400);
        }

        wp_send_json_success(array('ok' => true));
    }
}

WQFS_Plugin::init();
