<?php
if (!defined('ABSPATH')) { exit; }

final class WQFS_Admin_Settings
{
    public static function init(): void
    {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_init', array(__CLASS__, 'settings'));
    }

    public static function menu(): void
    {
        add_options_page(
            'Chat Quote Form Simple',
            'Chat Quote Form Simple',
            'manage_options',
            'wqfs-settings',
            array(__CLASS__, 'page')
        );
    }

    public static function settings(): void
    {
        register_setting('wqfs_group', 'wqfs_settings', array(__CLASS__, 'sanitize'));

        add_settings_section('wqfs_main', 'Main', function(){
            echo '<p>Set the destination phone number and optional reCAPTCHA.</p>';
        }, 'wqfs-settings');

        add_settings_field('phone', 'Destination Phone Number', array(__CLASS__, 'field_phone'), 'wqfs-settings', 'wqfs_main');

        add_settings_section('wqfs_captcha', 'Captcha (Google reCAPTCHA v2)', function(){
            echo '<p>If enabled, the button is disabled until captcha is completed.</p>';
        }, 'wqfs-settings');

        add_settings_field('captcha_enabled', 'Enable reCAPTCHA', array(__CLASS__, 'field_enabled'), 'wqfs-settings', 'wqfs_captcha');
        add_settings_field('captcha_site_key', 'reCAPTCHA Site Key', array(__CLASS__, 'field_site'), 'wqfs-settings', 'wqfs_captcha');
        add_settings_field('captcha_secret_key', 'reCAPTCHA Secret Key', array(__CLASS__, 'field_secret'), 'wqfs-settings', 'wqfs_captcha');
    }

    public static function sanitize($input): array
    {
        $out = array();

        $rawPhone = isset($input['phone']) ? sanitize_text_field((string)$input['phone']) : '';
        $out['phone'] = preg_replace('/[^0-9]/', '', $rawPhone) ?: '';

        $out['captcha_enabled'] = isset($input['captcha_enabled']) ? '1' : '0';
        $out['captcha_site_key'] = isset($input['captcha_site_key']) ? sanitize_text_field((string)$input['captcha_site_key']) : '';
        $out['captcha_secret_key'] = isset($input['captcha_secret_key']) ? sanitize_text_field((string)$input['captcha_secret_key']) : '';

        return $out;
    }

    private static function opts(): array
    {
        $o = get_option('wqfs_settings', array());
        return is_array($o) ? $o : array();
    }

    public static function field_phone(): void
    {
        $o = self::opts();
        $v = isset($o['phone']) ? (string)$o['phone'] : '';
        echo '<input class="regular-text" type="text" name="wqfs_settings[phone]" value="' . esc_attr($v) . '" placeholder="e.g. 447000000000" />';
        echo '<p class="description">Use international format (digits only).</p>';
    }

    public static function field_enabled(): void
    {
        $o = self::opts();
        $checked = (isset($o['captcha_enabled']) && $o['captcha_enabled'] === '1');
        echo '<label><input type="checkbox" name="wqfs_settings[captcha_enabled]" value="1" ' . checked(true, $checked, false) . ' /> Enable captcha</label>';
    }

    public static function field_site(): void
    {
        $o = self::opts();
        $v = isset($o['captcha_site_key']) ? (string)$o['captcha_site_key'] : '';
        echo '<input class="regular-text" type="text" name="wqfs_settings[captcha_site_key]" value="' . esc_attr($v) . '" />';
    }

    public static function field_secret(): void
    {
        $o = self::opts();
        $v = isset($o['captcha_secret_key']) ? (string)$o['captcha_secret_key'] : '';
        echo '<input class="regular-text" type="password" autocomplete="new-password" name="wqfs_settings[captcha_secret_key]" value="' . esc_attr($v) . '" />';
    }

    public static function page(): void
    {
        if (!current_user_can('manage_options')) { return; }

        echo '<div class="wrap"><h1>Chat Quote Form Simple</h1>';
        echo '<p>Shortcode: <code>[chat_quote_form]</code></p>';
        echo '<form method="post" action="options.php">';
        settings_fields('wqfs_group');
        do_settings_sections('wqfs-settings');
        submit_button();
        echo '</form>';
        echo '<p style="margin-top:16px;color:#666;font-size:12px;">Plugin by <a href="https://www.service-evesham.uk" target="_blank" rel="nofollow noopener">GsmHelp</a></p>';
        echo '</div>';
    }
}

WQFS_Admin_Settings::init();
